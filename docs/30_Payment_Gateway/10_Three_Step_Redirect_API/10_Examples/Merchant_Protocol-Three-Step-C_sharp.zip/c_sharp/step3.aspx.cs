﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ThreeStepExample
{
    public partial class step3 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            LabelResponse.Text = Server.HtmlEncode(Session["data"].ToString());
            if (!Session["result"].Equals("1"))
            {
                LabelResponseText.Text = (string)Session["result-text"];
            }
            else
            {
                LabelResponseText.Text = "";
            }
        }
    }
}
